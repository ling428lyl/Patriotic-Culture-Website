package com.hong;


import com.hong.dao.ExerciseMapper;
import com.hong.entity.Exercise;
import com.hong.entity.News;
import com.hong.service.ExerciseService;
import com.hong.service.NewsService;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class galleryTest {

    @Autowired
    private NewsService ns;

    @Autowired
    private ExerciseService es;

    @Test
    public void testEx(){
        StringBuilder sb = new StringBuilder();
        for(int i=13;i<=19;i++){
            sb.append("newsImgs/").append(i+".jpg").append(",");
        }
        System.out.println(sb.toString());
    }


    //@Test
    public void newsShow(){

        News news = ns.getById(4);
        System.out.println(news.getContent());

    }


    public void testLength(){

        String str ="新华国际时评：香港无需“美式竞选”那一套";
        System.out.println("长度"+str.length());
    }

    //@Test
    public void testShow(){

        List<News> list = ns.getLatestNews(null);
        for (News news : list) {
            System.out.println(news);
        }
    }

    //@Test
    /*插入测试数据使用*/
    public void saveMoreExercise(){

        String[] questions = {"新文化运动的基本口号是", "中国新民主主义革命阶段的开端是", "1919年5月爆发的五四运动是", "在新文化运动中率先举起马克思主义旗帜是",
                "作为中国新民主主义革命领导核心的中国共产党是", "第一次国共合作正式形成的标志是", "在近代中国，实现国家富强和人民富裕的前提条件是",
                "中国近代史上人民群众第一次大规模的反侵略武装斗争是", "魏源在《海国图志》中提出的重要思想是", "在19世纪60年代到90年代，洋务派兴办洋务事业的主要目的是"};

        String[] answers ={"C", "D", "D", "D", "C", "A", "B", "A", "A", "B"};


        String[] optionAs = {"民主和自由", "护国运动", "世界社会主义革命阶段的开端", "毛泽东", "社会主义思潮与中国革命相结合的产物",
                "国民党一大的召开", "反对帝国主义的侵略", "三元里人民的抗英斗争", "师夷长技以制夷", "开展中国的资本主义经济"};

        String[] optionBs = {"平等和博爱", "护法运动", "中国社会主义革命阶段的开端", "蔡和森", "新文化运动与中国革命相结合的产物",
                "中共二大的召开", "争得民族独立和人民解放", "太平天国的抗击洋枪队斗争", "中学为体、西学为用", "维护和稳固清王朝的封建统治"};
        String[] optionCs = {"民主和科学", "五卅运动", "中国旧民主主义革命阶段的开端", "陈独秀", "马克思主义与中国工人运动相结合的产物",
                "中共三大的召开", "推翻封建主义的统治", "高山族人民的抗美斗争", "救亡图存和振兴中华", "学习西方资本主义的制度"};
        String[] optionDs = {"理性和科学", "五四运动", "中国新民主主义革命阶段的开端", "李大钊", "中国知识分子与工人阶级相结合的产物",
                "中共一大的召开", "建立资本主义制度", "义和团的抗击八国联军斗争", "物竞天择、适者生存", "保卫国家的主权独立和民族尊严"};

        List<Exercise> list = new ArrayList<>();

        for(int i = 0;i<10;i++){

            Exercise exercise = new Exercise();
            exercise.setTitle(questions[i]);
            exercise.setAnswer(answers[i]);
            exercise.setOptionA(optionAs[i]);
            exercise.setOptionB(optionBs[i]);
            exercise.setOptionC(optionCs[i]);
            exercise.setOptionD(optionDs[i]);
            list.add(exercise);
        }

        for (Exercise exercise : list) {

            System.out.println("习题： "+exercise);
        }

        boolean b = es.saveBatch(list);
        System.out.println(b?"成功！":"失败！");
    }
}

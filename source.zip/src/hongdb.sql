
-- ----------------------------
-- Table structure for `do`
-- ----------------------------
DROP TABLE IF EXISTS `do`;
CREATE TABLE `do` (
  `did` int(10) NOT NULL AUTO_INCREMENT,
  `answer` char(3) NOT NULL COMMENT '正确答案',
  `title` varchar(200) NOT NULL COMMENT '题目',
  `optionA` varchar(200) DEFAULT NULL COMMENT 'A选项',
  `optionB` varchar(200) DEFAULT NULL COMMENT 'B选项',
  `optionC` varchar(200) DEFAULT NULL COMMENT 'C选项',
  `optionD` varchar(200) DEFAULT NULL COMMENT 'D选项',
  `doti` varchar(200) DEFAULT NULL COMMENT '答题',
  `fen` int(10) DEFAULT '0',
  `dotime` varchar(200) DEFAULT NULL COMMENT '答题',
  `username` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of do
-- ----------------------------

INSERT INTO `do` VALUES ('47', 'C', '新文化运动的基本口号是', '民主和自由', '平等和博爱', '民主和科学', '理性和科学', 'D', '0', ' 2022年06月08日 22:00:27', 'ces');
INSERT INTO `do` VALUES ('48', 'C', '新文化运动的基本口号是', '民主和自由', '平等和博爱', '民主和科学', '理性和科学', 'A', '0', ' 2022年06月08日 22:00:29', 'ces');
INSERT INTO `do` VALUES ('49', 'C', '新文化运动的基本口号是', '民主和自由', '平等和博爱', '民主和科学', '理性和科学', 'C', '20', ' 2022年06月08日 22:00:30', 'ces');
INSERT INTO `do` VALUES ('50', 'C', '新文化运动的基本口号是', '民主和自由', '平等和博爱', '民主和科学', '理性和科学', 'D', '0', ' 2022年06月08日 22:00:31', 'ces');

-- ----------------------------
-- Table structure for `exercise`
-- ----------------------------
DROP TABLE IF EXISTS `exercise`;
CREATE TABLE `exercise` (
  `eid` int(10) NOT NULL AUTO_INCREMENT,
  `answer` char(3) NOT NULL COMMENT '正确答案',
  `title` varchar(200) NOT NULL COMMENT '题目',
  `optionA` varchar(200) DEFAULT NULL COMMENT 'A选项',
  `optionB` varchar(200) DEFAULT NULL COMMENT 'B选项',
  `optionC` varchar(200) DEFAULT NULL COMMENT 'C选项',
  `optionD` varchar(200) DEFAULT NULL COMMENT 'D选项',
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of exercise
-- ----------------------------
INSERT INTO `exercise` VALUES ('1', 'C', '毛泽东思想初步形成是在？', '党的创立时期', '国民革命时期', '土地革命战争前中期', '土地革命战争后期');
INSERT INTO `exercise` VALUES ('2', 'C', '新文化运动的基本口号是', '民主和自由', '平等和博爱', '民主和科学', '理性和科学');
INSERT INTO `exercise` VALUES ('3', 'B', '无产阶级政党的第一个党纲是？', '《共产主义者同盟章程》', '《共产党宣言》', '《共产主义原理》', '《共产主义》');
INSERT INTO `exercise` VALUES ('4', 'C', '人民解放战争战略性决战的第一个大决战是', '平津战役', '淮海战役', '辽沈战役', '百团大战');
INSERT INTO `exercise` VALUES ('5', 'B', '新民主主义统一战线的主体是？', '无产阶级的联盟', '劳动者的联盟', '非劳动者的联盟', '劳动者与非劳动者的联盟');
INSERT INTO `exercise` VALUES ('6', 'D', '1985年5月，中国政府决定裁减军队员额（）万？', '50', '60', '80', '100');


-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '超级管理员', '可访问所有界面及所有的管理功能');
INSERT INTO `role` VALUES ('2', '普通用户', '可访问一般界面');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `phone` char(11) DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `register_time` datetime NOT NULL COMMENT '用户注册时间',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin', '12345678910', '1', '2022-06-05 10:02:20');
INSERT INTO `user` VALUES ('2', 'ming', '123', '12345678901', '1', '2022-06-05 10:20:20');
INSERT INTO `user` VALUES ('3', 'ces', '123456', '16676542789', '1', '2022-06-07 16:33:36');
INSERT INTO `user` VALUES ('4', 'ces6', '123456', '16676542876', '1', '2022-06-07 17:12:22');

-- ----------------------------
-- Table structure for `relationship`
-- ----------------------------
DROP TABLE IF EXISTS `relationship`;
CREATE TABLE `relationship` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '用户id',
  `rid` int(10) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of relationship
-- ----------------------------
INSERT INTO `relationship` VALUES ('1', '1', '1');
INSERT INTO `relationship` VALUES ('2', '2', '2');
INSERT INTO `relationship` VALUES ('3', '3', '2');
INSERT INTO `relationship` VALUES ('4', '4', '2');

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `comment`
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `nid` int(10) NOT NULL COMMENT '新闻id',
  `uname` varchar(50) NOT NULL COMMENT '用户名',
  `content` varchar(200) NOT NULL COMMENT '评论内容',
  `comment_date` datetime NOT NULL COMMENT '评论时间',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of comment
-- ----------------------------

INSERT INTO `comment` VALUES ('1', '1', 'ces6', '2121', '2022-06-07 17:12:38');


-- ----------------------------
-- Table structure for `news`
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `nid` int(10) NOT NULL AUTO_INCREMENT,
  `img_url` varchar(100) NOT NULL COMMENT '新闻图片url',
  `title` varchar(100) NOT NULL COMMENT '新闻标题',
  `content` varchar(1000) NOT NULL COMMENT '新闻内容',
  `news_date` datetime NOT NULL COMMENT '新闻发布时间',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态 0：下架；1：展示中',
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', 'image/gd1.jpg', '广大红色长廊', '红色长廊红色长廊', '2022-06-05 10:25:09', '1');


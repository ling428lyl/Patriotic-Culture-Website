package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.Comment;

import java.util.List;


public interface CommentService extends IService<Comment> {
    List<Comment> getByNid(Integer nid);

}

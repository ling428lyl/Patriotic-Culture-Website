package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.User;

import java.util.List;



public interface UserService extends IService<User> {

    User login(User user);

    int register(User user);

    List<User> findList();

    List<User> findMore(User user);
}

package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.Dp;
import com.hong.entity.Exercise;

import java.util.List;



public interface DpService extends IService<Dp> {
    List<Dp> getAll();
    List<Dp> getList(Integer size);
    List<Dp> getMore(String title);
    List<Dp> getMoreByUser(String username);
}

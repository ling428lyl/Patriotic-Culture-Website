package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.Role;


public interface RoleService extends IService<Role> {

}

package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.News;

import java.util.List;



public interface NewsService extends IService<News> {

    public boolean newsListSave(List<News> list);

    List<News> getLatestNews(Integer size);

    List<News> findMore(News news);

    int saveNews(News news);
}

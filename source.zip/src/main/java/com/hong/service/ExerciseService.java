package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.Exercise;

import java.util.List;



public interface ExerciseService extends IService<Exercise> {
    List<Exercise> getAll();
    List<Exercise> getList(Integer size);
    List<Exercise> getMore(String title);
	Exercise getOne(int eid);
}

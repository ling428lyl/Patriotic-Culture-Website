package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.RoleMenu;



public interface RoleMenuService extends IService<RoleMenu> {

}

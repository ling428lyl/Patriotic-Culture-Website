package com.hong.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hong.entity.Menu;



public interface MenuService extends IService<Menu> {

}

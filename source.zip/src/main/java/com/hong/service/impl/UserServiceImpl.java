package com.hong.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hong.dao.RoleMapper;
import com.hong.dao.UserMapper;
import com.hong.dao.UserRoleMapper;
import com.hong.entity.Role;
import com.hong.entity.User;
import com.hong.entity.UserRole;
import com.hong.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;



@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    @Autowired
    private UserMapper um;
    @Autowired
    private RoleMapper rm;
    @Autowired
    private UserRoleMapper urm;
    /*用户登录*/
    @Override
    public User login(User user) {

        /*根据用户名和密码查询*/
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username",user.getUsername()).eq("password",user.getPassword());
        User u = um.selectOne(queryWrapper);
        if (u != null) {
            /*获取该用户的角色id*/
            QueryWrapper<UserRole> queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.eq("uid", u.getUid());
            UserRole userRole = urm.selectOne(queryWrapper2);
            u.setRid(userRole.getRid());
        }
        return u;
    }

    /*有多条sql语句操作，给该方法添加事务管理*/
    @Transactional
    @Override
    public int register(User user) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("username").eq("username",user.getUsername());
        User u = um.selectOne(queryWrapper);

        //用户名重复不进行保存
        if(u!=null){
            return 0;
        }else{//用户名可用
            user.setStatus(1);//设置用户状态为正常，1：正常；0：封号状态
            //设置注册日期
            user.setRegisterTime(new Date());
            //保存用户
            int insert = um.insert(user);

            //查询“普通用户”的角色id
            QueryWrapper<Role> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.select("rid").eq("rolename","普通用户");
            Role role = rm.selectOne(queryWrapper1);

            // 给用户绑定到角色
            UserRole ur = new UserRole();
            ur.setUid(user.getUid());
            ur.setRid(role.getRid());
            urm.insert(ur);

            return insert;
        }
    }

    /*查找所有用户*/
    @Override
    public List<User> findList() {
        List<User> list = um.selectList(null);
        return list;
    }

    /*按指定条件查询用户*/
    @Override
    public List<User> findMore(User user) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        String username = user.getUsername();
        String phone = user.getPhone();
        Integer status = user.getStatus();
        /*如果这些条件不为空，就加入筛选用户*/
        if(username!=null && ""!=(username)){
            queryWrapper.like("username",username);
        }
        if(phone!=null && ""!=(phone)){
            queryWrapper.like("phone",phone);
        }
        if(status!=null){
            queryWrapper.eq("status",status);
        }
        List<User> list = um.selectList(queryWrapper);
        return list;
    }
}

package com.hong.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hong.dao.NewsMapper;
import com.hong.entity.News;
import com.hong.service.NewsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Service
public class NewsServiceImpl extends ServiceImpl<NewsMapper, News> implements NewsService {

    @Autowired
    private NewsMapper nm;


    /*测试时插入数据用*/
    @Override
    public boolean newsListSave(List<News> list) {
        boolean b = this.saveBatch(list);
        return b;
    }

    /*保存新闻*/
    @Override
    public int saveNews(News news) {
        //如果没有存图片，默认两张
        if(news.getImgUrl()==null||""==news.getImgUrl()){
            news.setImgUrl("image/gd1.jpg,image/gd5.jpg");
        }
        news.setNewsDate(new Date());
        news.setStatus(1);
        int insert = nm.insert(news);
        return insert;
    }

    /*主页请求返回最新的size条新闻*/
    @Override
    public List<News> getLatestNews(Integer size) {

        QueryWrapper<News> queryWrapper = new QueryWrapper<>();
        //筛选日期最新的前size条,并且是查询正在展示的新闻
        if(size!=null){
            String limitSize = "limit "+size;
            queryWrapper.orderByDesc("news_Date").last(limitSize).eq("status",1);
        }
        List<News> list = nm.selectList(queryWrapper);
        for (News news : list) {
            //主页只是展示标题，内容太大，设置为空，减少传输耗时
            news.setImgUrl(null);
            news.setContent(null);
            String title = news.getTitle();
            //如果文章标题过长
            if(title.length()>20){
                String newTitle = title.substring(0,20)+"...";
                news.setTitle(newTitle);
            }
        }
        return list;
    }

    /*按照指定条件查询新闻*/
    @Override
    public List<News> findMore(News news) {
        QueryWrapper<News> queryWrapper = new QueryWrapper<>();
        String title = news.getTitle();
        Integer status = news.getStatus();
        /*如果某些条件不为空，就加入筛选*/
        if(title!=null && ""!= title){
            queryWrapper.like("title",title);
        }
        if(status!=null){
            queryWrapper.eq("status",status);
        }
        List<News> list = nm.selectList(queryWrapper);
        return list;
    }
}

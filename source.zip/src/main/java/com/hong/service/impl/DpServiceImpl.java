package com.hong.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hong.dao.DpMapper;
import com.hong.entity.Dp;
import com.hong.entity.Result;
import com.hong.service.DpService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



@Service
public class DpServiceImpl extends ServiceImpl<DpMapper, Dp> implements DpService {

    @Autowired
    private DpMapper em;

    @Override
    public List<Dp> getMore(String title) {
        /*根据题目查找对应习题*/
        QueryWrapper<Dp> queryWrapper = new QueryWrapper<>();
        if(title!=null&&title!=""){
            queryWrapper.like("title",title);
        }
        List<Dp> list = em.selectList(queryWrapper);
        return list;
    }

    /*返回指定数目的练习题*/
    @Override
    public List<Dp> getList(Integer size) {
        //获取所有练习的eid，用list存储
        QueryWrapper<Dp> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("eid");
        List<Dp> eids = em.selectList(queryWrapper);
        //单独抽取出eid
        List<Integer> temp = new ArrayList<>();
        for (Dp eid : eids) {
            temp.add(eid.getDid());
        }
        /*随机打乱习题顺序，再抽取size道题目封装成一个新的list*/
        Collections.shuffle(temp);
        List<Integer> tmp = temp.subList(0, size);
        /*根据各个eid去查找相应的题目，返回最终的习题集*/
        List<Dp> list = em.selectBatchIds(tmp);
        return list;

    }

    @Override
    public List<Dp> getAll() {
        List<Dp> list = em.selectList(null);

        /*数据处理*/
        for (Dp Dp : list) {
            String title = Dp.getTitle();
            String optionA = Dp.getOptionA();
            String optionB = Dp.getOptionB();
            String optionC = Dp.getOptionC();
            String optionD = Dp.getOptionD();
            /*如果题目和选项过长，截取前边的规定字数*/
            if(title.length()>20){
                Dp.setTitle(title.substring(0,20)+"...");
            }
            if(optionA.length()>10){
                Dp.setOptionA(optionA.substring(0,10)+"...");
            }
            if(optionB.length()>10){
                Dp.setOptionB(optionB.substring(0,10)+"...");
            }
            if(optionC.length()>10){
                Dp.setOptionC(optionC.substring(0,10)+"...");
            }if(optionD.length()>10){
                Dp.setOptionA(optionD.substring(0,10)+"...");
            }
        }
        return list;

    }

	@Override
	public List<Dp> getMoreByUser(String username) {
		// TODO Auto-generated method stub
		 /*根据题目查找对应记录*/
        QueryWrapper<Dp> queryWrapper = new QueryWrapper<>();
        if(username!=null&&username!=""){
            queryWrapper.eq("username",username);
        }
        List<Dp> list = em.selectList(queryWrapper);
        return list;
	}
}

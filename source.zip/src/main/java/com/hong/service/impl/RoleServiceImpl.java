package com.hong.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hong.dao.RoleMapper;
import com.hong.entity.Role;
import com.hong.service.RoleService;

import org.springframework.stereotype.Service;



@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {

}

package com.hong.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hong.dao.ExerciseMapper;
import com.hong.entity.Dp;
import com.hong.entity.Exercise;
import com.hong.entity.Result;
import com.hong.service.ExerciseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



@Service
public class ExerciseServiceImpl extends ServiceImpl<ExerciseMapper, Exercise> implements ExerciseService {

    @Autowired
    private ExerciseMapper em;

    @Override
    public List<Exercise> getMore(String title) {

        /*根据题目查找对应习题*/
        QueryWrapper<Exercise> queryWrapper = new QueryWrapper<>();
        if(title!=null&&title!=""){
            queryWrapper.like("title",title);
        }
        List<Exercise> list = em.selectList(queryWrapper);
        return list;

    }

    /*返回指定数目的练习题*/
    @Override
    public List<Exercise> getList(Integer size) {

        //获取所有练习的eid，用list存储
        QueryWrapper<Exercise> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("eid");
        List<Exercise> eids = em.selectList(queryWrapper);
        //单独抽取出eid
        List<Integer> temp = new ArrayList<>();
        for (Exercise eid : eids) {
            temp.add(eid.getEid());
        }
        /*随机打乱习题顺序，再抽取size道题目封装成一个新的list*/
        Collections.shuffle(temp);
        List<Integer> tmp = temp.subList(0, size);

        /*根据各个eid去查找相应的题目，返回最终的习题集*/
        List<Exercise> list = em.selectBatchIds(tmp);

        return list;

    }


    @Override
    public List<Exercise> getAll() {

        List<Exercise> list = em.selectList(null);
        /*数据处理*/
        for (Exercise exercise : list) {

            String title = exercise.getTitle();
            String optionA = exercise.getOptionA();
            String optionB = exercise.getOptionB();
            String optionC = exercise.getOptionC();
            String optionD = exercise.getOptionD();

            /*如果题目和选项过长，截取前边的规定字数*/
            if(title.length()>20){
                exercise.setTitle(title.substring(0,20)+"...");
            }
            if(optionA.length()>10){
                exercise.setOptionA(optionA.substring(0,10)+"...");
            }
            if(optionB.length()>10){
                exercise.setOptionB(optionB.substring(0,10)+"...");
            }
            if(optionC.length()>10){
                exercise.setOptionC(optionC.substring(0,10)+"...");
            }if(optionD.length()>10){
                exercise.setOptionA(optionD.substring(0,10)+"...");
            }
        }

        return list;

    }

	@Override
	public Exercise getOne(int eid) {
		// TODO Auto-generated method stub
		QueryWrapper<Exercise> queryWrapper = new QueryWrapper<>();
        
        queryWrapper.eq("eid",eid);
        
		return em.selectOne(queryWrapper);
	}
}

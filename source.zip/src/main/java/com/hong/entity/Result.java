package com.hong.entity;

import java.util.HashMap;


public class Result extends HashMap<String,Object> {
    private static final long serialVersionUID = 1L;
    public Result() {
    }


//    请求成功（有参数）
    public static Result success(String msg){
        Result result = new Result();
        result.put("status","success");
        result.put("msg",msg);
        return result;
    }

//    请求成功（无参数）
    public static Result success(){
        Result result = new Result();
        result.put("status","success");
        return result;
    }

//    请求失败
    public static Result error(String msg){
        Result result = new Result();
        result.put("status","error");
        result.put("msg",msg);
        return result;
    }

//   添加数据
    public Result put(String key,Object value){
        super.put(key,value);
        return this;
    }

}

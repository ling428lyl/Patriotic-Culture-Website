package com.hong.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.*;

import java.io.Serializable;


@TableName("exercise")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Data
public class Exercise extends Model<Exercise> {

    private static final long serialVersionUID=1L;

    @TableId(value = "eid", type = IdType.AUTO)
    private Integer eid;//题目id
    private String answer;
    private String title;
    @TableField("optionA")
    private String optionA;
    @TableField("optionB")
    private String optionB;
    @TableField("optionC")
    private String optionC;
    @TableField("optionD")
    private String optionD;

    public void setTitle(String title) {
        this.title = title;
    }

    public void setOptionD(String optionD) {
        this.optionD = optionD;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getTitle() {
        return title;
    }

    public String getOptionD() {
        return optionD;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getAnswer() {
        return answer;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }
}

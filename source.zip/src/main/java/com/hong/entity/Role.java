package com.hong.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.*;

import java.io.Serializable;


@TableName("role")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Data
public class Role extends Model<Role> {
    private static final long serialVersionUID=1L;
    @TableId(value = "rid", type = IdType.AUTO)
    private Integer rid;
    private String rolename;
    private String remark;

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public Integer getRid() {
        return rid;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getRemark() {
        return remark;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }
}

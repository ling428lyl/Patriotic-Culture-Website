package com.hong.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.*;

import java.io.Serializable;
import java.util.Date;



@TableName("news")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Data
public class News extends Model<News> {

    private static final long serialVersionUID=1L;

    @TableId(value = "nid", type = IdType.AUTO)
    private Integer nid;
    private String imgUrl;//图片
    private String title;
    private String content;//内容
    private Date newsDate;//发布时间
    private Integer status;//状态

    @TableField(exist = false)
    private String[] imgs;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getNewsDate() {
        return newsDate;
    }

    public Integer getNid() {
        return nid;
    }

    public Integer getStatus() {
        return status;
    }

    public String getContent() {
        return content;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public String[] getImgs() {
        return imgs;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setImgs(String[] imgs) {
        this.imgs = imgs;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public void setNewsDate(Date newsDate) {
        this.newsDate = newsDate;
    }

    public void setNid(Integer nid) {
        this.nid = nid;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}

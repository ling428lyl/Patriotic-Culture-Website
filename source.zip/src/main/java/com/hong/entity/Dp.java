package com.hong.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.*;

import java.io.Serializable;


@TableName("do")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Data
public class Dp extends Model<Dp> {

    private static final long serialVersionUID=1L;

    @TableId(value = "did", type = IdType.AUTO)
    private Integer did;
    private String answer;
    private String title;
    @TableField("optionA")
    private String optionA;
    @TableField("optionB")
    private String optionB;
    @TableField("optionC")
    private String optionC;
    @TableField("optionD")
    private String optionD;
    @TableField("doti")//做题选项
    private String doti;
    @TableField("fen")//分数选项
    private int fen;
    @TableField("dotime")//时间选项
    private String dotime;
    @TableField("username")
    private String username;

    public Integer getDid() {
        return did;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getFen() {
        return fen;
    }

    public String getAnswer() {
        return answer;
    }

    public String getDoti() {
        return doti;
    }

    public String getOptionA() {
        return optionA;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDotime() {
        return dotime;
    }

    public String getUsername() {
        return username;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public String getTitle() {
        return title;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public void setDoti(String doti) {
        this.doti = doti;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public void setDotime(String dotime) {
        this.dotime = dotime;
    }

    public void setFen(int fen) {
        this.fen = fen;
    }

    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public void setOptionD(String optionD) {
        this.optionD = optionD;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}

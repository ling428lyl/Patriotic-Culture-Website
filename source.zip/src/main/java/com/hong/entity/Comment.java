package com.hong.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.*;

import java.io.Serializable;
import java.util.Date;


@TableName("comment")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Data
public class Comment extends Model<Comment> {

    private static final long serialVersionUID=1L;

    @TableId(value = "cid", type = IdType.AUTO)
    private Integer cid;//评论id
    private Integer nid;//新闻id
    private String uname;
    private String content;
    private Date commentDate;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public void setNid(Integer nid) {
        this.nid = nid;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public Integer getNid() {
        return nid;
    }

    public Date getCommentDate() {
        return commentDate;
    }

    public Integer getCid() {
        return cid;
    }

    public String getUname() {
        return uname;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public void setCommentDate(Date commentDate) {
        this.commentDate = commentDate;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }
}

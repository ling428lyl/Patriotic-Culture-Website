package com.hong.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hong.entity.Comment;

import org.apache.ibatis.annotations.Mapper;



@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

}

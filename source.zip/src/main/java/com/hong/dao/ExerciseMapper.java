package com.hong.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hong.entity.Exercise;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ExerciseMapper extends BaseMapper<Exercise> {

}

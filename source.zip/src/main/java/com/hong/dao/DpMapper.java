package com.hong.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hong.entity.Dp;
import com.hong.entity.Exercise;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface DpMapper extends BaseMapper<Dp> {

}

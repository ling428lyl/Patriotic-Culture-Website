package com.hong.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hong.entity.News;

import org.apache.ibatis.annotations.Mapper;



@Mapper
public interface NewsMapper extends BaseMapper<News> {

}

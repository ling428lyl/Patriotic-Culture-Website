package com.hong.controller;


import com.hong.entity.Comment;
import com.hong.entity.News;
import com.hong.entity.Result;
import com.hong.service.CommentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RequestMapping("/comment")
@RestController
public class CommentController {

    @Autowired
    private CommentService cs;

    /*保存评论*/
    @PostMapping("/save")
    public Result saveComment(Comment comment){
        comment.setCommentDate(new Date());
        boolean save = cs.save(comment);
        if(save){
            return Result.success();
        }else{
            return Result.error("评论失败");
        }
    }

    /*根据新闻的nid获取所有的相关评论*/
    @PostMapping("/list")
    public Result findComment(Integer nid){
        List<Comment> list = cs.getByNid(nid);
        return Result.success().put("list",list);
    }

}


package com.hong.controller;


import com.hong.entity.News;
import com.hong.entity.Result;
import com.hong.entity.User;
import com.hong.service.NewsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;



@RequestMapping("/news")
@RestController
public class NewsController {

    @Autowired
    private NewsService ns;

    /*保存新闻*/
    @PostMapping("/save")
    public Result newsSave(News news){
        int i = ns.saveNews(news);
        return Result.success();
    }

    /*新闻内容展示*/
    @RequestMapping(value = "/show",method = {RequestMethod.GET,RequestMethod.POST})
    public Result newsShow(Integer nid){
        if(nid==null){
            return Result.error("nid为空");
        }
        News news = ns.getById(nid);
        String title = news.getTitle();
        //如果文章标题过长
        if(title.length()>20){
            String newTitle = title.substring(0,20);
            news.setTitle(newTitle);
        }
        //把数据库里的地址汇总字符串拆分为字符数组，在后端处理数据再交给前端
        String imgUrl = news.getImgUrl();
        String[] split = imgUrl.split(",");
        news.setImgs(split);
        //设置为null，减少传输耗时
        news.setImgUrl(null);
        return Result.success().put("news",news);
    }

    /*修改时回显数据*/
    @GetMapping("/content")
    public void newsContent(Integer nid,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(nid==null){
            return ;
        }
        News news = ns.getById(nid);
        /*没显示的数据一律设置为空，减少传输损耗*/
        news.setNewsDate(null);
        news.setImgs(null);
        news.setImgUrl(null);
        request.setAttribute("news",news);
        request.getRequestDispatcher("/newsEditor.jsp").forward(request,response);
    }

//index页面发来ajax请求，回显数据
    @PostMapping("/list")
    public Result newsList(Integer size){
        //按照日期排序，返回最新的新闻
        List<News> list = ns.getLatestNews(size);
        return Result.success().put("list",list);

    }

//    新闻管理界面请求返回所有结果
    @GetMapping("/all")
    public void newsFindAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer size = null;
        //参数为null代表查询全部
        List<News> list = ns.getLatestNews(size);
        request.setAttribute("list",list);
        request.getRequestDispatcher("/newsList.jsp").forward(request,response);
    }

    /*查询指定条件的新闻*/
    @PostMapping("/find")
    public void newsFindMore(News news,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<News> list = ns.findMore(news);
        request.setAttribute("list",list);
        request.getRequestDispatcher("/newsList.jsp").forward(request,response);
    }

    /*更新新闻*/
    @PostMapping("/update")
    public void newsUpdate(News news,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        news.updateById();
        this.newsFindAll(request, response);
    }

    /*改变新闻状态*/
    @GetMapping("/changeStatus")
    public void userChangeStatus(News news, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer status = news.getStatus();
        news.setStatus(status==1?0:1);
        news.updateById();
        this.newsFindAll(request,response);
    }
}


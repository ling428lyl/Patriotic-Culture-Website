package com.hong.controller;



import com.hong.entity.Result;
import com.hong.entity.User;
import com.hong.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.List;


@RequestMapping("/user")
@RestController
public class UserController {

    @Autowired
    private UserService us;

    /*用户登录*/
    @PostMapping("/login")
    public void userLogin(User user, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
            User u =us.login(user);
            if(u==null){
                //用户登录失败
                request.setAttribute("loginMsg","用户名或密码错误");
                request.getRequestDispatcher("/login.jsp").forward(request,response);
            }else if(u.getStatus()==0){
                //用户被封号
                request.setAttribute("loginMsg","登录失败，账号已被封禁！");
                request.getRequestDispatcher("/login.jsp").forward(request,response);
            }else{
                //用户登录成功
                session.setAttribute("user",u);
                response.sendRedirect(request.getContextPath()+"/index.jsp");
            }
    }

    /*用户注册*/
    @PostMapping("/register")
    public void userRigister(User user,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
            int i = us.register(user);
            if(i==0){
                //用户名重复注册失败，跳转回注册页面
                request.setAttribute("registerMsg","用户名重复");
                request.getRequestDispatcher("/register.jsp").forward(request,response);
            }else{
                //注册成功，重定向到登录页面
                response.sendRedirect(request.getContextPath()+"/index.jsp");
            }
    }

    /*用户注销*/
    @PostMapping("/loginOut")
    public Result userLoginOut(HttpSession session){
        session.invalidate();
        return Result.success();
    }

    /*用户数据回显（用于用户修改信息时显示原先数据）*/
    @GetMapping("/getOne")
    public void userFindOne(Integer uid,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User u = us.getById(uid);
        request.setAttribute("updateUser",u);
        request.getRequestDispatcher("/userUpdate.jsp").forward(request,response);

    }

    /*获取所有用户*/
    @GetMapping("/list")
    public void userList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<User> list = us.findList();
        request.setAttribute("list",list);
        request.getRequestDispatcher("/userList.jsp").forward(request,response);
    }

    /*查询指定条件的用户*/
    @PostMapping("/find")
    public void userFindMore(User user,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<User> list = us.findMore(user);
        request.setAttribute("list",list);
        request.getRequestDispatcher("/userList.jsp").forward(request,response);

    }

    /*更新用户*/
    @PostMapping("/update")
    public void userUpdate(User user,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        user.updateById();
        response.sendRedirect(request.getContextPath()+"/index.jsp");
    }

    /*更改用户的账号状态*/
    @GetMapping("/changeStatus")
    public void userChangeStatus(User user,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Integer status = user.getStatus();
        user.setStatus(status==1?0:1);
        user.updateById();//mybatisPlus的AR模式处理简单更新
        this.userList(request,response);//刷新用户列表
    }

    /*删除用户*/
    @GetMapping("/delete")
    public void userDelete(Integer uid,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
        if(uid==null){
            return;
        }else{
            user.setUid(uid);
        }
        user.deleteById();//mybatisPlus的AR模式处理简单更新
        //刷新用户列表
        this.userList(request,response);
    }
}


package com.hong.controller;


import com.hong.entity.Exercise;
import com.hong.entity.Result;
import com.hong.service.ExerciseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



@RequestMapping("/exercise")
@RestController
public class ExerciseController {

    @Autowired
    private ExerciseService es;

    /*题目回显（用于点击修改时，显示原先的数据）*/
    @GetMapping("/show")
    public void getExercise(Integer eid,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Exercise exercise = es.getById(eid);
        request.setAttribute("exercise",exercise);
        request.getRequestDispatcher("/exerciseEditor.jsp").forward(request,response);
    }

    /*删除题目*/
    @GetMapping("/delete")
    public void deleteExercise(Integer eid,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        es.removeById(eid);
        /*删除后刷新列表*/
        this.findExercise(request, response);
    }

    /*随机获取指定数目的题目*/
    @PostMapping("/list")
    public Result getExercise(Integer size){
        List<Exercise> list = es.getList(size);
        return Result.success().put("list",list);
    }

    /*查找所有的题目*/
    @GetMapping("/all")
    public void findExercise(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Exercise> list = es.getAll();

        request.setAttribute("list",list);
        request.getRequestDispatcher("/exerciseList.jsp").forward(request,response);
    }

    /*根据题目查找题目*/
    @PostMapping("/find")
    public void findMoreExercise(String title,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Exercise> list = es.getMore(title);
        request.setAttribute("list",list);
        request.getRequestDispatcher("/exerciseList.jsp").forward(request,response);
    }

    /*更新或保存题目*/
    @PostMapping("/save")
    public void saveExercise(Exercise exercise,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /*更新或保存*/
        exercise.insertOrUpdate();
        //刷新题目列表
        this.findExercise(request,response);

    }




}


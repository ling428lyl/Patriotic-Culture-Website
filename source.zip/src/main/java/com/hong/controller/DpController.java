package com.hong.controller;


import com.hong.entity.Dp;
import com.hong.entity.Exercise;
import com.hong.entity.Result;
import com.hong.entity.User;
import com.hong.service.DpService;
import com.hong.service.ExerciseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@RequestMapping("/dp")
@RestController
public class DpController {

    @Autowired
    private DpService es;

    @Autowired
    private ExerciseService ex;

    /*删除题目*/
    @GetMapping("/delete")
    public void deleteDp(Integer did,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        es.removeById(did);
        /*删除后刷新列表*/
        this.findDp(request, response);
    }

    /*知识竞答随机获取指定数目的题目*/
    @PostMapping("/list")
    public Result getDp(Integer size){
        List<Dp> list = es.getList(size);
        return Result.success().put("list",list);
    }

    /*管理员查找所有的答题记录*/
    @GetMapping("/all")
    public void findDp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Dp> list = es.getAll();
        request.setAttribute("list",list);
        request.getRequestDispatcher("/allDpList.jsp").forward(request,response);
    }

    /*用户查找自己所有的答题记录*/
    @GetMapping("/userall")
    public void finduserDp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	User u = (User) request.getSession().getAttribute("user");
        List<Dp> list = es.getMoreByUser(u.getUsername());
        request.setAttribute("list",list);
        request.getRequestDispatcher("/DpList.jsp").forward(request,response);
    }
    
    /*根据题目查找答题记录*/
    @PostMapping("/find")
    public void findMoreDp(String title,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Dp> list = es.getMore(title);
        request.setAttribute("list",list);
        request.getRequestDispatcher("/allDpList.jsp").forward(request,response);
    }

    /*保存答题记录*/
    @PostMapping("/save")
    public void saveDp(Dp Dp,int eid,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Exercise e = ex.getOne(eid);
        /*更新或保存*/
    	Dp.setTitle(e.getTitle());
    	Dp.setOptionA(e.getOptionA());
    	Dp.setOptionB(e.getOptionB());
    	Dp.setOptionC(e.getOptionC());
    	Dp.setOptionD(e.getOptionD());
    	Dp.setAnswer(e.getAnswer());
    	System.out.println(e.toString());
    	User u = (User) request.getSession().getAttribute("user");
    	Dp.setUsername(u.getUsername());
    	SimpleDateFormat sdf = new SimpleDateFormat( " yyyy年MM月dd日 HH:mm:ss" );
    	String str = sdf.format(new Date());
    	Dp.setDotime(str);
        Dp.insertOrUpdate();
        //刷新题目列表
        this.findDp(request,response);

    }

    /*删除题目*/
    @GetMapping("/userdelete")
    public void userdeleteDp(Integer did,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        es.removeById(did);
        /*删除后刷新列表*/
        this.finduserDp(request, response);
    }


}

